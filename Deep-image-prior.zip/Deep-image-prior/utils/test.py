from __future__ import print_function
import matplotlib.pyplot as plt
import os
import numpy as np
import torch
from models import *  # Ensure this imports your model
import torch.optim
from skimage.metrics import peak_signal_noise_ratio
from denoising_utils import *  # Ensure this imports necessary utility functions

torch.backends.cudnn.enabled = True
torch.backends.cudnn.benchmark = True

dtype = torch.cuda.FloatTensor
imsize = -1
PLOT = True
sigma = 25
sigma_ = sigma / 255.0

# Load test image
fname = 'path to test image'  # Change this to your test image path
img_noisy_pil = crop_image(get_image(fname, imsize)[0], d=32)
img_noisy_np = pil_to_np(img_noisy_pil)
# Since we don't have ground truth in blind denoising, the noisy image is the input
img_pil = img_noisy_pil
img_np = img_noisy_np

if PLOT:
    plot_image_grid([img_np], 4, 5)

# Set network and optimization parameters
INPUT = 'noise'  # 'meshgrid' or 'noise'
pad = 'reflection'
OPT_OVER = 'net'  # 'net' or 'input'
reg_noise_std = 1. / 30.  # Adjust based on noise level
LR = 0.01
OPTIMIZER = 'adam'  # Could also use 'LBFGS'
show_every = 100
exp_weight = 0.99

# Network and parameters based on image type
num_iter = 2400
input_depth = 3
figsize = 5
net = skip(
    input_depth, 3,
    num_channels_down=[8, 16, 32, 64, 128],
    num_channels_up=[8, 16, 32, 64, 128],
    num_channels_skip=[0, 0, 0, 4, 4],
    upsample_mode='bilinear',
    need_sigmoid=True, need_bias=True, pad=pad, act_fun='LeakyReLU')
net = net.type(dtype)

# Create noisy input (blind denoising)
net_input = get_noise(input_depth, INPUT, (img_pil.size[1], img_pil.size[0])).type(dtype).detach()

# Compute number of parameters
s = sum([np.prod(list(p.size())) for p in net.parameters()])
print(f'Number of params: {s}')

# Loss function (MSE)
mse = torch.nn.MSELoss().type(dtype)

# Convert noisy image to tensor
img_noisy_torch = np_to_torch(img_noisy_np).type(dtype)
net_input_saved = net_input.detach().clone()
noise = net_input.detach().clone()
out_avg = None
last_net = None
psrn_noisy_last = 0
i = 0

# Initialize a list to store SNR values for each iteration
snr_values = []


# Function to calculate SNR
def calculate_snr(denoised_img, ground_truth_img):
    psnr_denoised = peak_signal_noise_ratio(denoised_img, ground_truth_img)
    L = 255
    snr_denoised = psnr_denoised - 10 * np.log10(L ** 2)
    return snr_denoised


# Function to save the image
def save_image(img_tensor, iteration, folder_path='../output_images'):
    """ Save the image tensor to a file. """
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    img_np = torch_to_np(img_tensor)
    img_np = np.clip(img_np, 0, 1)
    img_pil = Image.fromarray((img_np[0] * 255).astype(np.uint8))
    img_pil.save(f"{folder_path}/image_iter_{iteration:04d}.png")


# Closure function for optimization
def closure():
    global i, out_avg, psrn_noisy_last, last_net, net_input
    if reg_noise_std > 0:
        net_input = net_input_saved + (noise.normal_() * reg_noise_std)

    # Forward pass through the network
    out = net(net_input)

    # Smoothing
    if out_avg is None:
        out_avg = out.detach()
    else:
        out_avg = out_avg * exp_weight + out.detach() * (1 - exp_weight)

    # Calculate total loss
    total_loss = mse(out, img_noisy_torch)
    total_loss.backward()

    # Calculate PSNR for noisy image and denoised output
    psrn_noisy = peak_signal_noise_ratio(img_noisy_np, out.detach().cpu().numpy()[0])
    psrn_gt = peak_signal_noise_ratio(img_np, out.detach().cpu().numpy()[0])
    psrn_gt_sm = peak_signal_noise_ratio(img_np, out_avg.detach().cpu().numpy()[0])

    # Print iteration info
    print(f'Iteration {i:05d} Loss {total_loss.item():.6f} PSNR_gt_sm: {psrn_gt_sm:.2f}', '\r', end='')

    # Save the image every 100 iterations
    if i % 100 == 0:
        save_image(out, i)

        # Calculate and store the SNR for the saved image
        snr_denoised = calculate_snr(out.detach().cpu().numpy()[0], img_np)
        snr_values.append(snr_denoised)
        print(f"Iteration {i:04d} SNR: {snr_denoised:.2f}")

    # Backtracking if the PSNR drops significantly
    if i % show_every:
        if psrn_noisy - psrn_noisy_last < -5:
            print('Falling back to previous checkpoint.')
            for new_param, net_param in zip(last_net, net.parameters()):
                net_param.data.copy_(new_param.cuda())
            return total_loss * 0
        else:
            last_net = [x.detach().cpu() for x in net.parameters()]
            psrn_noisy_last = psrn_noisy

    i += 1
    return total_loss


# Get parameters and start optimization
p = get_params(OPT_OVER, net, net_input)
optimize(OPTIMIZER, p, closure, LR, num_iter)

# Final output and PSNR calculation
out_np = torch_to_np(net(net_input))

# Crop or resize output to match the original image size (if necessary)
if out_np.shape != img_np.shape:
    out_np = out_np[:, :img_np.shape[1], :img_np.shape[2]]

psnr_denoised = peak_signal_noise_ratio(out_np, img_np)
print(f"Final PSNR: {psnr_denoised:.2f}")
L = 255
snr_denoised = psnr_denoised - 10 * np.log10(L ** 2)
print(f"Final SNR: {snr_denoised:.2f}")

# Plot denoised result vs original noisy image
q = plot_image_grid([np.clip(out_np, 0, 1), img_np], factor=13)


# Function to plot SNR curve
def plot_snr_curve():
    plt.figure(figsize=(10, 6))
    plt.plot(range(0, len(snr_values) * 100, 100), snr_values, marker='o')
    plt.xlabel('Epoch')
    plt.ylabel('SNR')
    plt.title('SNR During Training')
    plt.grid(True)
    plt.savefig('../snr_curve.png')  # Save the SNR curve to a file
    plt.show()


# Function to delete saved images
def delete_saved_images(folder_path='../output_images'):
    """ Delete all saved images in the output folder """
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        if os.path.isfile(file_path):
            os.remove(file_path)
    print(f"Deleted all images in {folder_path}")


# After training, plot the SNR curve and delete saved images
plot_snr_curve()
delete_saved_images()
