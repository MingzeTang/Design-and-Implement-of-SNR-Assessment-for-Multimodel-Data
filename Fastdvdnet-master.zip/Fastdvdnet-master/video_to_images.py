import cv2
import os


def video_to_frames(video_path, output_dir, max_frames=25):
    cap = cv2.VideoCapture(video_path)

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS)

    frames_to_extract = min(total_frames, max_frames)

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for frame_idx in range(frames_to_extract):
        ret, frame = cap.read()
        if not ret:
            break

        frame_filename = os.path.join(output_dir, f"frame_{frame_idx:04d}.png")
        cv2.imwrite(frame_filename, frame)

    cap.release()
    print(f"Extracted {frames_to_extract} frames to {output_dir}")

video_to_frames("path to video", "path to image_sequence", max_frames=25)
