from gradio_client import Client

client = Client("https://resembleai-resemble-enhance.hf.space/--replicas/lnwdi/")
result = client.predict(
		"sample-9s.wav",	# filepath  in 'Input Audio' Audio component
		"Midpoint",	# Literal[Midpoint, RK4, Euler]  in 'CFM ODE Solver (Midpoint is recommended)' Dropdown component
		1,	# float (numeric value between 1 and 128) in 'CFM Number of Function Evaluations (higher values in general yield better quality but may be slower)' Slider component
		0,	# float (numeric value between 0 and 1) in 'CFM Prior Temperature (higher values can improve quality but can reduce stability)' Slider component
		True,	# bool  in 'Denoise Before Enhancement (tick if your audio contains heavy background noise)' Checkbox component
							api_name="/predict"
)
print(result)